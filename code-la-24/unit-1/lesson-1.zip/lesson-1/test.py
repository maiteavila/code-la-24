x = 5
if x > 5:
    print("Greather than fiiiiiiiiiive!!!!!")
else:
    print("boopa")