i = 0
while i < 25:
    if i % 2 == 0:
        print(i)
    i = i + 1
